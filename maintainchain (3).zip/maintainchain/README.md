# MaintainChain – a tamper-proof machine maintenance log

Blockchain Technology (CSE4444) · Assignment 2
Author: Uzair Qureshi · Reg. No. 220905158

MaintainChain is a decentralized application (DApp) on Ethereum that records service history for industrial machines (CNC mills, lathes, compressors and so on). Only authorised technicians can log a service, every entry is stamped with the technician's wallet and the block time, and no entry can be edited or deleted afterwards.

## 1. Problem

Factories and workshops usually keep machine service records in paper logbooks or shared spreadsheets. That causes three problems:

- **Records can be altered.** After a breakdown or a failed safety audit, entries can be back-dated, edited or quietly filled in.
- **No proof of who did the work.** A signature in a logbook is easy to fake, and a spreadsheet cell has no author.
- **Buyers and auditors can't trust the history.** When used equipment is sold or an insurer investigates a failure, there is no independent record to check.

## 2. Solution

The smart contract acts as a shared logbook that nobody can rewrite.

| Role | Who | Can do |
|---|---|---|
| Owner | Account that deploys the contract (facility manager) | Register machines, add and remove technicians, log services |
| Technician | Wallets added by the owner | Log services |
| Viewer | Any wallet (auditor, buyer, insurer) | Read machines, full service history and overdue status |

Each service entry stores the machine ID, a description of the work, a condition rating from 1 (critical) to 5 (excellent), the technician's address, the timestamp and the next due date. The contract can tell anyone whether a machine is overdue for service.

## 3. Repository structure

```
maintainchain/
├── contracts/MaintainChain.sol    Solidity smart contract
├── frontend/
│   ├── index.html                 User interface
│   ├── style.css                  Styles
│   ├── app.js                     MetaMask + Ethers.js logic
│   ├── abi.js                     Contract ABI (generated)
│   ├── config.js                  Deployed address and chain ID
│   └── lib/ethers.umd.min.js      Ethers.js v6.13.4 (bundled so it works offline)
├── test/
│   ├── MaintainChain.test.js      19 automated tests (valid, invalid, unauthorised)
│   └── test-results.txt           Output of the test run
├── scripts/compile.js             Compiles the contract and regenerates abi.js
├── build/MaintainChain.json       ABI + bytecode
├── docs/DEPLOYMENT.md             Deployment details and transaction evidence
├── screenshots/                   Evidence screenshots
└── package.json
```

## 4. Smart contract overview

**State variables:** `owner`, `facilityName`, `machineCount`, `recordCount`, `technicianCount`, mappings for machines, technicians and records, plus `MAX_ID_LENGTH` and `MAX_TEXT_LENGTH` constants.

**Constructor:** `constructor(string _facilityName)` sets the deployer as owner, stores the facility name and makes the owner a technician. It rejects an empty or overly long name.

**Functions:**

| Function | Access | Purpose |
|---|---|---|
| `registerMachine(id, name, location)` | Owner | Add a machine |
| `addTechnician(address)` / `removeTechnician(address)` | Owner | Manage technicians |
| `logMaintenance(id, workDone, condition, nextDueAt)` | Technician | Record a service |
| `getMachine(id)`, `getMachineHistory(id)`, `getRecord(n)` | Anyone | Read data |
| `getAllMachineIds()`, `isOverdue(id)`, `roleOf(address)` | Anyone | Read data |

**Validation (`require`):** required fields, maximum lengths, no duplicate machine IDs, condition between 1 and 5, next due date in the future, machine must exist, no zero address, owner cannot be removed.

**Authorisation (modifiers):** `onlyOwner`, `onlyTechnician`, `machineExists`.

**Events:** `MachineRegistered`, `TechnicianAdded`, `TechnicianRemoved`, `MaintenanceLogged`.

## 5. Running the application

### Prerequisites

- [MetaMask](https://metamask.io/) browser extension
- [Ganache](https://archive.trufflesuite.com/ganache/) (desktop app), or the CLI: `npx ganache --chain.chainId 1337 --server.port 7545`
- [Remix IDE](https://remix.ethereum.org)
- Python 3 or the VS Code Live Server extension, to serve the frontend

### Step 1 – Start Ganache

Open Ganache and click **Quickstart (Ethereum)**. Note the RPC server (`HTTP://127.0.0.1:7545`) and that it lists 10 accounts with 100 ETH each.

### Step 2 – Connect MetaMask to Ganache

1. MetaMask → network menu → **Add a network** → **Add a network manually**.
2. Enter: Network name `Ganache Local`, RPC URL `http://127.0.0.1:7545`, Chain ID `1337`, Currency symbol `ETH`. Save and switch to it.
3. In Ganache, click the key icon next to an account and copy its private key. In MetaMask choose **Add account or hardware wallet → Import account** and paste it. Import three accounts and rename them:
   - **Account 1 – Owner** (Ganache account 0, which you will deploy from)
   - **Account 2 – Technician**
   - **Account 3 – Outsider** (used for unauthorised tests)

These are throw-away Ganache test keys. Never commit private keys or seed phrases to this repository.

### Step 3 – Compile in Remix

1. Open Remix, create `MaintainChain.sol` and paste in `contracts/MaintainChain.sol`.
2. Solidity Compiler tab → compiler `0.8.24`.
3. **Advanced Configurations → EVM version → `paris`.** This is required for Ganache, which does not support the `PUSH0` opcode that newer EVM targets use. Without it, deployment fails with an "invalid opcode" error.
4. Click **Compile MaintainChain.sol**.

### Step 4 – Deploy

1. Deploy & Run tab → Environment: **Injected Provider – MetaMask**. MetaMask should be on Ganache Local with Account 1 selected. Remix shows `Custom (1337) network`.
2. Next to **Deploy**, enter the facility name, for example `Bay 2 Machine Shop`.
3. Click **Deploy** and confirm in MetaMask.
4. Copy the contract address from **Deployed Contracts** (or the Remix terminal).

### Step 5 – Run the frontend

1. Open `frontend/config.js` and set `CONTRACT_ADDRESS` to the copied address. Leave `EXPECTED_CHAIN_ID = 1337`.
2. Serve the folder over HTTP (MetaMask does not inject into `file://` pages):
   ```bash
   cd frontend
   python -m http.server 8000
   ```
   Then open <http://localhost:8000>. VS Code Live Server also works.
3. Click **Connect MetaMask** and approve. The header shows your role (Owner, Technician or Viewer), address, chain and balance.

### Step 6 – Use the DApp

1. As **Owner**: register a machine (e.g. `CNC-01`, `Haas VF-2 CNC mill`, `Bay 2, line A`).
2. As **Owner**: paste Account 2's address into Technicians and click **Add technician**.
3. Switch MetaMask to **Account 2**. The page reloads and shows **Technician**. Log a service on `CNC-01`.
4. Click a machine in the table to see its service history, read directly from the chain.
5. Every transaction appears in the **Transaction log** with its hash, block and gas used.

The form fields intentionally have no browser-side limits on condition or dates, so invalid values reach the contract and are rejected by its `require` checks. By default the page simulates each transaction first and stops it if it would revert. Tick **Send transactions even if they will fail** to send it anyway, so a reverted transaction is mined and recorded on-chain.

### Troubleshooting

- **"Nonce too high" after restarting Ganache:** MetaMask → Settings → Advanced → **Clear activity tab data**.
- **"No contract exists at CONTRACT_ADDRESS":** Ganache was restarted (its chain resets), or the address in `config.js` is wrong. Redeploy and update the address.
- **Invalid opcode on deploy:** set the EVM version to `paris` (Step 3).

## 6. Deployment details

| Item | Value |
|---|---|
| Network | Ganache local (chain ID 1337, RPC `http://127.0.0.1:7545`) |
| Contract address | `0x________________________________________` |
| Deployer / owner | `0x________________________________________` |
| Deployment transaction hash | `0x________________________________________` |
| Compiler | solc 0.8.24, EVM version paris, optimizer on (200 runs) |
| Constructor argument | `Bay 2 Machine Shop` |

Full transaction evidence is in [`docs/DEPLOYMENT.md`](docs/DEPLOYMENT.md).

## 7. Test cases

The contract was tested in three ways:

1. **Automated:** `npm install && npm test` runs 19 tests against an in-memory Ganache chain. All 19 pass. Output: [`test/test-results.txt`](test/test-results.txt).
2. **Remix:** each function called from the Deployed Contracts panel with the owner, technician and outsider accounts.
3. **Frontend:** the same cases through the UI with MetaMask.

### Valid inputs

| ID | Account | Action / input | Expected result | Observed result |
|---|---|---|---|---|
| V1 | Owner | Deploy with `"Bay 2 Machine Shop"` | Deployed; owner and facility name set | Passed |
| V2 | Owner | `registerMachine("CNC-01", "Haas VF-2 CNC mill", "Bay 2, line A")` | Success; machineCount = 1; `MachineRegistered` event | Passed |
| V3 | Owner | `addTechnician(<Account 2>)` | Success; `roleOf` returns 1 (Technician) | Passed |
| V4 | Technician | `logMaintenance("CNC-01", "Spindle lubricated, coolant replaced", 4, <+30 days>)` | Success; history has 1 entry with technician's address | Passed |
| V5 | Anyone | `isOverdue("CNC-01")` after the due date passes | Returns `true` | Passed |
| V6 | Outsider | `getAllMachineIds()`, `getMachineHistory("CNC-01")` | Data returned (reads are public) | Passed |

### Invalid inputs

| ID | Account | Action / input | Expected result | Observed result |
|---|---|---|---|---|
| I1 | Owner | `registerMachine("", "Lathe", "Bay 1")` | Revert: `Machine ID is required` | Reverted as expected |
| I2 | Owner | `registerMachine("CNC-01", …)` again | Revert: `Machine ID already registered` | Reverted as expected |
| I3 | Owner | Machine ID of 33 characters | Revert: `Machine ID is too long (max 32)` | Reverted as expected |
| I4 | Technician | `logMaintenance(…, condition = 7, …)` | Revert: `Condition must be between 1 and 5` | Reverted as expected |
| I5 | Technician | `logMaintenance(…, nextDueAt = yesterday)` | Revert: `Next due date must be in the future` | Reverted as expected |
| I6 | Technician | `logMaintenance("CNC-01", "", …)` | Revert: `Describe the work done` | Reverted as expected |
| I7 | Technician | `logMaintenance("NOPE-99", …)` | Revert: `Machine not found` | Reverted as expected |
| I8 | Owner | `addTechnician(0x000…000)` | Revert: `Invalid address` | Reverted as expected |

### Unauthorised inputs

| ID | Account | Action / input | Expected result | Observed result |
|---|---|---|---|---|
| U1 | Outsider | `registerMachine("LATHE-01", …)` | Revert: `Only the owner can do this` | Reverted as expected |
| U2 | Technician | `addTechnician(<Account 3>)` | Revert: `Only the owner can do this` | Reverted as expected |
| U3 | Outsider | `logMaintenance("CNC-01", "Fake service entry", 5, …)` | Revert: `Only an authorised technician can log maintenance` | Reverted as expected |
| U4 | Technician (after removal) | `logMaintenance(…)` | Revert: `Only an authorised technician can log maintenance` | Reverted as expected |
| U5 | Owner | `removeTechnician(<owner>)` | Revert: `Owner cannot be removed` | Reverted as expected |

## 8. Screenshots

| # | What it shows | File |
|---|---|---|
| 1 | Smart contract compilation in Remix | ![Compilation](screenshots/01-compilation.png) |
| 2 | Smart contract deployment (Remix + MetaMask confirmation) | ![Deployment](screenshots/02-deployment.png) |
| 3 | MetaMask wallet connection to the DApp | ![MetaMask connection](screenshots/03-metamask-connection.png) |
| 4 | Successful transaction (service logged) | ![Successful transaction](screenshots/04-successful-transaction.png) |
| 5 | Failed transaction (unauthorised or invalid input reverted) | ![Failed transaction](screenshots/05-failed-transaction.png) |
| 6 | Blockchain data displayed in the UI (machine table and service history) | ![Blockchain data in UI](screenshots/06-blockchain-data-ui.png) |

## 9. Tech stack

Solidity 0.8.24 · Remix IDE · Ganache · MetaMask · Ethers.js 6.13.4 · HTML, CSS, JavaScript · Node.js test runner

## 10. Security note

This repository contains no private keys, seed phrases or passwords. The accounts used are local Ganache test accounts with no real value.
